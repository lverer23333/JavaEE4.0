package edu.bjtu.reative.repositories;

import edu.bjtu.reative.models.Course;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CourseRepository extends ReactiveMongoRepository<Course, String> {
	Mono<Course> findById(String id);
    Flux<Course> findAll();
    Mono<Course> save(Course course);
    Mono<Void> deleteById(String id);
}
