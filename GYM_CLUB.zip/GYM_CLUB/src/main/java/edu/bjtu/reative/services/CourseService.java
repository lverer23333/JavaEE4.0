package edu.bjtu.reative.services;

import edu.bjtu.reative.models.Course;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CourseService {
    Mono<Coach> findById(String id);
    Flux<Coach> findAll();
    Mono<Coach> save(Coach coach);
    Mono<Coach> deleteById(String id);
}