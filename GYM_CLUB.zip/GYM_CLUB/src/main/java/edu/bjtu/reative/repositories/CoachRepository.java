package edu.bjtu.reative.repositories;

import edu.bjtu.reative.models.Book;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface CoachRepository extends ReactiveMongoRepository<Book, String> {

}
