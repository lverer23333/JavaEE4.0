package edu.bjtu.ee4j.repository.primary;

import edu.bjtu.reative.models.Book;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface ContactRepository extends ReactiveMongoRepository<Book, String> {

}
