package edu.bjtu.reative.repositories;

import edu.bjtu.reative.models.Contact;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ContactRepository extends ReactiveMongoRepository<Book, String> {
    Mono<Contact> findById(String id);
    Flux<Contact> findAll();
}
