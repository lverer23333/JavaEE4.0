package edu.bjtu.ee4j.controllers;

import edu.bjtu.reative.models.Person;
import edu.bjtu.reative.repositories.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping(value = { "", "/", "/home" })
public class HomeController  {
	
    /*
    public ModelAndView index(WebRequest request,Coach coach, Model model) {
        model.addAttribute("activePage", "home");
    
        long lastModified =6L; // 1. 应用相关的方式计算得到(application-specific calculation)
        if (request.checkNotModified(lastModified)) {
        	        // 2. 快速退出 — 不需要更多处理了
        	        return null;
         }
        	    System.out.println("这是没有缓存的界面1");
        return new ModelAndView("/index");
    }*/
   
}
