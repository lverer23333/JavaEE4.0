package edu.bjtu.reative.controllers;

import edu.bjtu.reative.models.Person;
import edu.bjtu.reative.repositories.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/Course")
public class CourseController {

    @Autowired
    private CourseRepository courseRepository;
    
    /*public CourseController(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }*/

    @GetMapping
    public Flux<Person> index() {
        return CourseRepository.findAll();
    }
    
    @GetMapping(value = "/Course/{id}")
    public Mono<Course> getCourseById(@PathVariable String id) {
        return CourseService.findById(id);
    }
    
    @GetMapping(value = "/Courses")
    public Flux<Course> getAllCourses() {
        return CourseService.findAll();
    }
    
    @PostMapping(value = "/Course")
    public Mono<Course> createCourse(@RequestBody Course Course) {
        return CourseService.save(Course);
    }

}
