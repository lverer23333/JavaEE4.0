package edu.bjtu.reative.security;

@Bean
public UserDetailsRepositoryResourceFactoryBean userDetailsService() {
    return UserDetailsRepositoryResourceFactoryBean
                  .fromResourceLocation("classpath:users.properties");
}
